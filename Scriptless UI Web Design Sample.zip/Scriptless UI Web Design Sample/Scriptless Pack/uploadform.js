const form = document.getElementById("upload-form");
const fileInput = document.getElementById("file-input");
const submitButton = document.getElementById("submit-button");

form.addEventListener("submit", event => {
  event.preventDefault();

  // handle the file upload process here
  const file = fileInput.files[0];
  console.log("Selected file:", file);

  // example code to send the file to a back-end server using fetch
  const formData = new FormData();
  formData.append("file", file);

  fetch("C:\\Users\admin\\Desktop\\Scriptless UI\\Uploaded_File", {
    method: "POST",
    body: formData
  })
    .then(response => response.json())
    .then(data => {
      console.log("File uploaded successfully:", data);
    })
    .catch(error => {
      console.error("File upload failed:", error);
    });
});
