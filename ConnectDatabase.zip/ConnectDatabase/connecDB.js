// import { application } from "express";

// script - api;
// api123;
// script - api123;
// script - application;

//DESKTOP-H6ALL3H\SQLEXPRESS
//testlogin
//123456 - expired
//zee123

var sql = require("mssql");
var config = {
  server: "DESKTOP-H6ALL3HSQLEXPRESS",
  database: "ScriptlessAPI",
  options: {
    trustedConnection: true,
  },
};

sql.connect(config, function (err) {
  if (err) console.log(err);
  var request = new sql.Request();
  request.query("select * from dbo.SampleTable", function (err, records) {
    if (err) console.log(err);
    else console.log(records);
  });
});
